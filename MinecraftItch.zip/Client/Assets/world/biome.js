class Biome {
    constructor({
        name,
        heightNoise = new Noise(),
        topLayer = Blocks.GrassBlock,
        secondLayer = Blocks.Dirt,
        firstLayerWidth = 1,
        secondLayerWidth = 3,
        treeType = [Trees.Oak],
        grassType = [Blocks.Grass, Blocks.TallGrass],
        treeThreshold = 55,
        minTemp = 0,
        maxTemp = 60,
        minWet = 60,
        maxWet = 0,
        minMount = 0,
        maxMount = 60,
        waterLevel = WATER_LEVEL,
        mobs = BiomeMobs.CommonMobs,
        googlies = BiomeMobs.Googlies,
        maxMobs = 4,

        fluidType = Blocks.Water,

        baseBlock = Blocks.Stone,

        waterSandType = Blocks.Sand,

        // Nether specific
        fullChunk = false,
    } = {}) {
        this.name = name;
        this.heightNoise = heightNoise;
        this.topLayer = topLayer;
        this.secondLayer = secondLayer;
        this.firstLayerWidth = firstLayerWidth;
        this.secondLayerWidth = secondLayerWidth;
        this.treeType = treeType;
        this.grassType = grassType;
        this.treeThreshold = treeThreshold;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.minWet = minWet;
        this.maxWet = maxWet;
        this.minMount = minMount;
        this.maxMount = maxMount;
        this.waterLevel = waterLevel;
        this.mobs = mobs;
        this.googlies = googlies;
        this.maxMobs = maxMobs;

        this.baseBlock = baseBlock;

        this.fluidType = fluidType;
        this.fullChunk = fullChunk;

        this.waterSandType = waterSandType;
    }
}

const BiomeMobs = Object.freeze({
    CommonMobs: ["Pig", "Cow", "Sheep"],
    Googlies: ["Zombie"],
});

const OverworldBiomes = Object.freeze({
    Plains: new Biome({
        name: "Plains",
        heightNoise: NoisePresets.Flat,
        topLayer: Blocks.GrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Oak, Trees.Birch],
        grassType: [Blocks.Grass, Blocks.TallGrass],
        treeThreshold: 7,
        minTemp: 10,
        maxTemp: 25,
        minWet: 0,
        maxWet: 10,
        minMount: 0,
        maxMount: 50,
    }),
    Desert: new Biome({
        name: "Desert",
        heightNoise: NoisePresets.Flat,
        mobs: [],
        topLayer: Blocks.Sand,
        secondLayer: Blocks.SandStone,
        firstLayerWidth: 2,
        treeType: [Trees.Cactus],
        grassType: [Blocks.DeadBush],
        treeThreshold: 7.3,
        minTemp: 25,
        maxTemp: Infinity,
        minWet: 0,
        maxWet: 10,
        minMount: 0,
        maxMount: 50,
    }),
    Tundra: new Biome({
        name: "Tundra",
        heightNoise: NoisePresets.Flat,
        topLayer: Blocks.SnowedGrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Spruce],
        grassType: [],
        treeThreshold: 7,
        minTemp: -Infinity,
        maxTemp: 15,
        minWet: 0,
        maxWet: Infinity,
        minMount: 0,
        maxMount: 50,
    }),
    Taiga: new Biome({
        name: "Taiga",
        heightNoise: NoisePresets.Flat,
        topLayer: Blocks.Podzol,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Spruce, Trees.BigSpruce],
        grassType: [Blocks.Grass, Blocks.TallGrass, Blocks.Fern],
        treeThreshold: 6.5,
        minTemp: 15,
        maxTemp: 20,
        minWet: 10,
        maxWet: 30,
        minMount: 0,
        maxMount: 50,
    }),
    Shrubland: new Biome({
        name: "Shrubland",
        heightNoise: NoisePresets.SmallHills,
        topLayer: Blocks.GrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Oak, Trees.Birch],
        grassType: [Blocks.Grass, Blocks.TallGrass],
        treeThreshold: 7,
        minTemp: 20,
        maxTemp: 30,
        minWet: 10,
        maxWet: 20,
        minMount: 0,
        maxMount: 50,
    }),
    Savanna: new Biome({
        name: "Savanna",
        heightNoise: NoisePresets.Flat,
        topLayer: Blocks.GrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Acacia],
        grassType: [Blocks.Grass, Blocks.TallGrass, Blocks.DeadBush],
        treeThreshold: 7,
        minTemp: 30,
        maxTemp: Infinity,
        minWet: 10,
        maxWet: 20,
        minMount: 0,
        maxMount: 50,
    }),
    Forest: new Biome({
        name: "Forest",
        heightNoise: NoisePresets.SmallHills,
        topLayer: Blocks.GrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Oak, Trees.Oak, Trees.Birch],
        grassType: [
            Blocks.Grass,
            Blocks.TallGrass,
            Blocks.Grass,
            Blocks.TallGrass,
            Blocks.Grass,
            Blocks.TallGrass,
            Blocks.FlowerRose,
            Blocks.FlowerBlueOrchid,
        ],
        treeThreshold: 6,
        minTemp: 20,
        maxTemp: 25,
        minWet: 20,
        maxWet: 30,
        minMount: 0,
        maxMount: 50,
    }),
    SeasonalForest: new Biome({
        name: "Seasonal Forest",
        heightNoise: NoisePresets.SmallHills,
        topLayer: Blocks.GrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Oak],
        grassType: [
            Blocks.Grass,
            Blocks.TallGrass,
            Blocks.FlowerAllium,
            Blocks.FlowerBlueOrchid,
            Blocks.FlowerDaisy,
            Blocks.FlowerDandelion,
            Blocks.FlowerRose,
            Blocks.FlowerTulipOrange,
            Blocks.FlowerTulipPink,
            Blocks.FlowerTulipRed,
            Blocks.FlowerTulipWhite,
            Blocks.FlowerSyringa,
        ],
        treeThreshold: 6.5,
        minTemp: 30,
        maxTemp: Infinity,
        minWet: 20,
        maxWet: 25,
        minMount: 0,
        maxMount: 50,
    }),
    Swamp: new Biome({
        name: "Swamp",
        heightNoise: NoisePresets.Flat,
        topLayer: Blocks.GrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.Oak],
        grassType: [Blocks.Grass, Blocks.TallGrass],
        treeThreshold: 7,
        minTemp: 10,
        maxTemp: 30,
        minWet: 30,
        maxWet: Infinity,
        minMount: 0,
        maxMount: 50,
        waterLevel: 30,
    }),
    RainForest: new Biome({
        name: "Rain Forest",
        heightNoise: NoisePresets.LowHills,
        topLayer: Blocks.GrassBlock,
        secondLayer: Blocks.Dirt,
        treeType: [Trees.BigJungle, Trees.Jungle],
        grassType: [Blocks.Grass, Blocks.TallGrass],
        treeThreshold: 7,
        minTemp: 30,
        maxTemp: Infinity,
        minWet: 30,
        maxWet: Infinity,
        minMount: 0,
        maxMount: 50,
    }),
    Mountain: new Biome({
        name: "Mountain",
        heightNoise: NoisePresets.Mountains,
        topLayer: Blocks.Stone,
        secondLayer: Blocks.Stone,
        treeType: [],
        grassType: [Blocks.Grass, Blocks.TallGrass],
        treeThreshold: 6,
        minTemp: 0,
        maxTemp: Infinity,
        minWet: 0,
        maxWet: Infinity,
        minMount: 50,
        maxMount: Infinity,
    }),
});

const NetherBiomes = Object.freeze({
    NetherWastes: new Biome({
        name: "Nether Wastes",
        topLayer: Blocks.Netherrack,
        secondLayer: Blocks.Netherrack,
        firstLayerWidth: 3,
        secondLayerWidth: 5,
        treeType: [],
        grassType: [],
        treeThreshold: Infinity,
        minTemp: 80,
        maxTemp: Infinity,
        minWet: -Infinity,
        maxWet: -50,
        minMount: 0,
        maxMount: 60,
        waterLevel: 5,
        mobs: [],
        googlies: [],
        maxMobs: 4,

        baseBlock: Blocks.Netherrack,
        fullChunk: true,

        fluidType: Blocks.Lava,

        waterSandType: Blocks.SoulSand,
    }),
});

const YvanBiomes = Object.freeze({
    Bob: new Biome({
        name: "Bob",
        heightNoise: NoisePresets.Mountains,
        topLayer: Blocks.AcaciaLeaves,
        secondLayer: Blocks.AcaciaLog,
        baseBlock: Blocks.TNT,
        waterLevel: 55,
        maxMobs: 16,
        waterSandType: Blocks.DiamondOre,
        fluidType: Blocks.Stone,
    }),
});

const AllBiomes = Object.freeze({
    ...OverworldBiomes,
    ...NetherBiomes,
});
