const Entities = Object.freeze({
    Pig: Pig,
    Cow: Cow,
    Zombie: Zombie,
    Sand: FallingBlock,
    Snowball: Snowball,
    Sheep: Sheep,
    WitherSkeleton: WitherSkeleton,
});
