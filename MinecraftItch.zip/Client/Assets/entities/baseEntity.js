class base extends Entity {
    hit() {}
    update() {}
    dieEvent() {}
    interact(player, item) {}
    tickUpdate() {}
}
